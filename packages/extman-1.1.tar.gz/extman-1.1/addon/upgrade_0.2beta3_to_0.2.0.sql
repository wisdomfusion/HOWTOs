use extmail;
ALTER TABLE `domain` ADD `hashdirpath` VARCHAR( 255 ) NOT NULL AFTER `description`;
